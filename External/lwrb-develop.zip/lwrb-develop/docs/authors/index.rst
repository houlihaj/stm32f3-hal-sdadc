.. _authors:

Authors
=======

List of authors and contributors to the library

.. literalinclude:: ../../AUTHORS