.. _changelof:

Changelog
=========

.. literalinclude:: ../../CHANGELOG.md
